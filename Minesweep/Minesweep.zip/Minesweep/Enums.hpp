#ifndef ENUMS_HPP_INCLUDED
#define ENUMS_HPP_INCLUDED

enum RetornosTabuleiro {
    ForaDoLimite = -2,
    LocalDeBomba = -1,
};

#endif // ENUMS_HPP_INCLUDED
